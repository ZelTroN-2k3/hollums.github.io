Alex Hollums
Project 4: Snake!

This is a rendition of the classic Nokia game called Snake.
Use the left, right, up, and down arrow keys to control the snake.
The object is not to run into the snakes body or a wall.
Try to hit the red squares with the head of the snake for points.

Press spacebar to pause, and again to resume.

When within the directory of hollums_proj4, type:
"make compile" - compile the program
"make run" - run the program
"make clean" - to clean up all .class files.

Enjoy!
